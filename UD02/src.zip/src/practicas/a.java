package practicas;

public class a {
    public static void main(String[] args) {
        String texto ="";
        texto ="a" +  "\n";
        texto += "b";
        System.out.println(texto);
    }
    
}

package EstructurasDeControlFunciones;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class E0409Test {
    @Test
    void testMayorDeTres() {
        assertEquals(2, E0409.mayorDeTres(1, 1, 2));

    }
}

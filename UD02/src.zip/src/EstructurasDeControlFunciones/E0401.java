package EstructurasDeControlFunciones;

public class E0401 {
    public static void main(String[] args) {
        eco(6);
    }
    public static void eco(int n){
        for (int i = 0; i < n; i++) {
            System.out.println("Eco " + i);
        }
        
    }
    
}

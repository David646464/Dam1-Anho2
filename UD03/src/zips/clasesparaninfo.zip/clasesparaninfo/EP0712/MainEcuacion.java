package clasesparaninfo.EP0712;

public class MainEcuacion {
    public static void main(String[] args) {
        Ecuacion ecuacion = new Ecuacion(4, 4, 1);
        ecuacion.calculo();
    }
    
}

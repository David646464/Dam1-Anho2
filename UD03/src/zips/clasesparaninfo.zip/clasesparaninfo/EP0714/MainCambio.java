package clasesparaninfo.EP0714;

public class MainCambio {
    public static void main(String[] args) {
        Cambio.devolverCambio(200, 500);
    }
    
}

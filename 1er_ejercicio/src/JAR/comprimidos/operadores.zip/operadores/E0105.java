//Creador:david sánchez peso
package operadores;

public class E0105 {
    public static void main(String[] args) {
        /*Programa que muestre que el rango de valores
         de un tipo short se comporta de forma cíclica,
          es decir, que el valor siguiente al máximo es
           el valor mínimo.*/
       short numero = 32767;
       short uno = 1;

       System.out.println("La variable numero tiene como valor" + numero);
       System.out.println("Si le incrementamos uno: " + numero + " 1 pasara al su valor mas pequeño funcionando de forma cíclica");
       
       System.out.println("Dando como resultado: " + -32768);

        

        
    }
}
